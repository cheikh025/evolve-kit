/**
 * Model-facing `candidate-builder` tool: runs a one-shot subagent hard-confined to ONE
 * directory through the `candidate-builder` provider on `ctx.subagents`. Foreground by
 * default: the call waits for the child to finish and returns its final text.
 * `run_in_background: true` starts the same run through the jobs service and
 * returns a job id immediately (collect with `job_output`, stop with
 * `job_kill`).
 *
 * The confinement payload (`root` + `allowShell` + optional `allowedTools`)
 * rides the start request as an extra `confine` field, which the subagents
 * service preserves verbatim.
 * @module dsh-candidate-builder/tool
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "tool-candidate-builder";
export declare const inject: string[];
/** Config: which registered provider this tool delegates to. */
export interface Config {
    /** The `ctx.subagents` provider name to start runs on (default `candidate-builder`). */
    provider: string;
    /** Model-facing tool name (default `candidate-builder`). */
    toolName?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=tool.d.ts.map