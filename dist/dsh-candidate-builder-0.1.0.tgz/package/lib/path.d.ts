/**
 * Case-normalized path containment for the candidate-builder confinement guard.
 *
 * Windows/UNC keys are fully lowercased (NTFS is case-insensitive); POSIX keys
 * keep their case. The functions are pure string logic and safe to run on any
 * platform, including inside the sandbox realms where Node path APIs are
 * unavailable.
 * @module dsh-candidate-builder/path
 */
/**
 * Canonicalize an absolute path into a comparable key: separators normalized,
 * `.` dropped, `..` collapsed (a pop below the root clamps to the root, which
 * is correct for the CONFINED ROOT itself — escape detection belongs to
 * {@link resolveInside}).
 * @param p - the path to canonicalize.
 * @returns the normalized key, or `null` when `p` is not absolute.
 */
export declare function normalizeAbs(p: string): string | null;
/**
 * Resolve `p` (absolute or relative) against the confined root and return the
 * normalized key when it stays inside, or `null` when it escapes — including
 * a relative `..` that climbs past the root and an absolute path on another
 * drive or share.
 * @param rootKey - the normalized confined root from {@link normalizeAbs}.
 * @param p - the candidate path argument.
 * @returns the contained normalized key, or `null` when `p` escapes.
 */
export declare function resolveInside(rootKey: string, p: string): string | null;
//# sourceMappingURL=path.d.ts.map