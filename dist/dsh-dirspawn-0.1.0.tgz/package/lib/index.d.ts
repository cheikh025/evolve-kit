/**
 * In-process DIRSPAWN subagent backend: registers a {@link SubagentProvider} on
 * `ctx.subagents` that runs each child as a fresh in-process child agent
 * hard-confined to ONE directory.
 *
 * Confinement layers, strongest first:
 * 1. The child session's `cwd` IS the confined directory and its sandbox mode
 *    is pinned to `workspace-write` — the file sandbox's write boundary.
 * 2. A monotonic tool guard registered in the child's scope validates the path
 *    argument of `read`/`write`/`edit`/`glob`/`grep`/`read_image` (absolute,
 *    relative, and `..` escapes) before the tool body runs.
 * 3. Skills stay available to every child (the catalog is instruction
 *    knowledge, never a path grant). Shell tools (pwsh/bash) are removed by
 *    default (visibility plus name denial) but grantable per child through the
 *    request's `allowedTools`. Delegation tools (subagent/workflow/ralph), the
 *    `dirspawn` tool itself, and the `cordis_*` dynamic-plugin tools are never
 *    grantable, so the child cannot spawn unguarded grandchildren or define
 *    plugins that read the host filesystem.
 * 4. The child's approval policy is pinned to `never`, so sandbox escalation
 *    (including `danger-full-access`) is impossible.
 *
 * The provider is one-shot only (no `prepareContinuable`), like the shipped
 * spawn backend but with its own child driver: the built-in in-process driver
 * always stamps the PARENT's cwd, while this backend must stamp the confined
 * directory.
 * @module dsh-dirspawn
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ResolvedSubagentStartRequest } from '@deepseek-ai/dsh-subagent';
export declare const name = "subagent-dirspawn";
export declare const inject: string[];
/** Config: the registry name to register the provider under. */
export interface Config {
    /** Provider name on `ctx.subagents` (default `dirspawn`). */
    providerName: string;
}
export declare const Config: z<Config>;
/**
 * Confinement payload carried as an extra field on the start request. The
 * subagents service resolves `{ ...request, descriptor }`, so this field
 * reaches the provider verbatim; start children through the companion
 * `dsh-dirspawn/tool` row, which always supplies it.
 */
export interface DirspawnConfine {
    /** Absolute directory the child may read and write; everything else is denied. */
    readonly root: string;
    /** Whether pwsh/bash stay enabled (workdir confined; arbitrary shell reads remain possible). */
    readonly allowShell: boolean;
    /** Extra tool names the delegating agent granted; never-grantable names are ignored. */
    readonly allowedTools?: readonly string[];
}
/** The start request a dirspawn child carries. */
export interface DirspawnStartRequest extends ResolvedSubagentStartRequest {
    readonly confine?: DirspawnConfine;
}
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map